<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Testimoni extends CI_Controller{

public function __construct(){
		parent::__construct();
		$this->load->model('M_testimoni');
		$this->load->model('M_testimoni_admin');                
		if ($this->session->userdata('username')=="") {
			redirect('home');
		}elseif($this->session->userdata('level') == "usr"){
			redirect('user/home');
		}
	}

	public function index() {
		$data = array(
					'error' => '',
					'username' => $this->session->userdata('username')
				);
		$data['hasiltransaksi'] = $this->M_testimoni->tampil_joinn();
		$this->load->view('admin/index1', $data);
		$this->load->view('admin/v_testimoni', $data);
		$this->load->view('admin/index2', $data);


	}

	public function TambahTestimoni(){		
		$nama = $this->input->post('nama');
		$tanggal = $this->input->post('tanggal');
		$isi_pembayaran = $this->input->post('isi_pembayaran');
		$norek = $this->input->post('norek');
		
		$data = array(
			'nama' => $nama,
			'tanggal' => $tanggal,
			'isi_pembayaran' => $isi_pembayaran,
			'norek' => $norek,
			
		);
		$this->M_testimoni_admin->tambah_data($data,'pembayaran');
		redirect('admin/testimoni');
	}
		 function hapustestimoni($id_pembayaran){		
        $where = array('id_pembayaran' => $id_pembayaran);
		$this->M_testimoni_admin->hapus_data($where,'pembayaran');
		redirect('admin/testimoni');
		
		
		
	 }
	 function edittestimoni($id_pembayaran){		
        $where = array('id_pembayaran' => $id_pembayaran);
        $data['testimoni'] = $this->M_testimoni_admin->edit_data($where,'pembayaran')->result();
		
		$this->load->view('admin/index1', $data);
		$this->load->view('admin/v_edittestimoni',$data);
		$this->load->view('admin/index2', $data);
		
		
		
	 }
	 public function UpdateTestimoni(){
	 	$id_pembayaran = $this->input->post('id_pembayaran');
		$nama = $this->input->post('nama');
		$isi_pembayaran = $this->input->post('isi_pembayaran');
		$tanggal = $this->input->post('tanggal');
		$norek = $this->input->post('norek');
		
		$data = array(
			'id_pembayaran' => $id_pembayaran,
			'nama' => $nama,
			'isi_pembayaran' => $isi_pembayaran,
			'tanggal' => $tanggal,
			'norek' => $norek
			
		);
		$where = array(
                	'id_pembayaran'=>$this->input->post('id_pembayaran') 
                );
                $this->M_testimoni_admin->update_data($where,$data,'pembayaran');
		redirect('admin/testimoni');
	}

}