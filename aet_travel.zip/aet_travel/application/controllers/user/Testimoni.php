<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Testimoni extends CI_Controller{

public function __construct(){
		parent::__construct();
		$this->load->model('M_testimoni');               
		if ($this->session->userdata('username')=="") {
			redirect('home');
		}elseif($this->session->userdata('level') == 'adm'){
			redirect('admin/Home');
		}
	}

	public function index() {
		$data = array(
					'error' => '',
					'username' => $this->session->userdata('username')
				);
		$where = array('pembayaran.id_user' => $_SESSION['id_user']);
		$data['hasiltransaksi'] = $this->M_testimoni->tampil_join($where,'pembayaran');
		$this->load->view('user/index1', $data);
		$this->load->view('user/v_testimoni', $data);
		$this->load->view('user/index2', $data);


	}

	public function TambahTestimoni(){		
		$nama = $this->input->post('nama');
		$id_user = $this->input->post('id_user');
		$tanggal = $this->input->post('tanggal');
		$isi_pembayaran = $this->input->post('isi_pembayaran');
		$norek = $this->input->post('norek');
		
		$data = array(
			'nama' => $nama,
			'tanggal' => $tanggal,
			'id_user' => $id_user,
			'isi_pembayaran' => $isi_pembayaran,
			'norek' => $norek,
			
		);
		$this->M_testimoni->tambah_data($data,'pembayaran');
		redirect('user/testimoni');
	}

		 function hapustestimoni($id_pembayaran){		
        $where = array('id_pembayaran' => $id_pembayaran);
		$this->M_testimoni->hapus_data($where,'pembayaran');
		redirect('user/testimoni');
		
		
		
	 }
	 function edittestimoni($id_pembayaran){		
        $where = array('id_pembayaran' => $id_pembayaran);
        $data['pembayaran'] = $this->M_testimoni->edit_data($where,'pembayaran')->result();
		
		$this->load->view('user/index1', $data);
		$this->load->view('user/v_edittestimoni',$data);
		$this->load->view('user/index2', $data);
		
		
		
	 }
	 public function UpdateTestimoni(){
	 	$id_pembayaran = $this->input->post('id_pembayaran');
		$nama = $this->input->post('nama');
		$isi_pembayaran = $this->input->post('isi_pembayaran');
		$tanggal = $this->input->post('tanggal');
		$norek = $this->input->post('norek');
		
		$data = array(
			'id_pembayaran' => $id_pembayaran,
			'nama' => $nama,
			'isi_pembayaran' => $isi_pembayaran,
			'tanggal' => $tanggal,
			'norek' => $norek
			
		);
		$where = array(
                	'id_pembayaran'=>$this->input->post('id_pembayaran') 
                );
                $this->M_testimoni->update_data($where,$data,'pembayaran');
		redirect('user/testimoni');
	}

}