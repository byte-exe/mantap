 <div class="container">

      <!-- pricing table -->
      <h1 class="heading">Kenapa Memilih Kami</h1>
<h4>AET Travel Internasional hadir ke tengah-tengah masyarakat Indonesia dengan tujuan mengemban amanah masyarakat yang ingin menunaikan umrah dan haji ke tanah suci.

Dengan jumlah penduduk 237 juta jiwa (BPS 2010), dan didominasi oleh masyarakat beragama Islam sekitar 207 juta jiwa (87,1%), tak mengheran permintaan umrah dan haji setiap tahunnya terus meningkat. Oleh karena itulah kami mencoba memfasilitasi dan menjembatani keinginan mulia tersebut.</h4>
</div>
<hr>