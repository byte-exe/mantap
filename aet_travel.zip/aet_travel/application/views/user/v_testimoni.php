    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          
            

            <div class="info-box-content">
           
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
 <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Upload Bukti Pembayaran</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <div class="btn-group">
                  
                  
                </div>
               
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <section class="content-header">
      
        <form action="<?=base_url()?>user/Testimoni/TambahTestimoni" method="post" enctype="multipart/form-data">

           <div class="form-group">
            <input type="hidden" name="tanggal" value="<?php date_default_timezone_set("Asia/Bangkok");
echo date(" d F Y ");?>">
                  <label for="exampleInput">Nama</label>
                  <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Nama" name="nama" value="<?php echo $_SESSION['nama'];  ?>" readonly required><br>
                  <div>
                    
                    <label for="exampleInputEmail1">No Rekening Tujuan</label>
                  <select name="norek" class="form-control" id="norek" required>
                    <option value="" hidden="">Pilih Rekening Tujuan</option>
                    <option value="bca">BCA : 0312312</option>
                    <option value="mandiri">Mandiri : 1312312312</option>
                    <option value="bri">BRI : 1312312312</option>
                    <option value="nagari">Nagari : 1312312312</option>
                    <option value="btn">BTN : 1312312312</option>
                  </select><br>
                
                  </div>
                  <label for="exampleInputPassword1">No Transaksi</label>
                  <textarea class="form-control" id="exampleInputPassword1" placeholder="No Transaksi Bukti Pembayaran" name="isi_pembayaran"  required></textarea><br>
                 
                 <input type="hidden" name="id_user" value="<?php echo $_SESSION['id_user'];  ?>">
                 


                
               
                <div class="box-footer">
                <button type="submit" class="btn btn-primary" >Kirim
                </button>
                <button type="reset" class="btn btn-warning">Reset</button>

              </div> </form>
              
    </section>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
     
      
            </div>
                        <div class="box-footer">
              
          
            </div>
       
          </div>
     
        </div>
  
      </div>
      </section>

              </div>
        
 
             
<script>
function myFunction() {
var result = confirm("Want to delete?");
if (result) {
    //Logic to delete the item
}
    document.getElementById("demo").innerHTML = x;
}
</script>          
              
