   <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          
            

            <div class="info-box-content">
           
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        
         
            
            <!-- /.box-header -->
<section class="content-header">
<div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Halaman Pelanggan AET Travel Internasional</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <div class="btn-group">
                  
                  
                </div>
               
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <section class="content-header">
      
      <h1 align="center">
       AET Travel Internasional<br>
       Cabang Padang pariaman
      </h1>
      
     <center><img src="<?php echo base_url() ?>assets/dist/img/LOGO.jpg" width="250" height="250"></center>
      <h4 align="center">
      Jln. Raya Sicincin, Pariaman KM. 7 Buluah Kasok Sungai Sariak Kec. VII Koto.
<br>
Telp. (021) 59407315
        
      </h4><br>
      <h1 align="center">
        Silahkan Isi Data Diri Pada Halaman Data Pelanggan dan untuk pemesanan<br> Silahkan melakukan Pemilihan Pada Halaman Pemesanan Pelanggan<br>
      </h1>
    </section>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
	</section>

              </div>
              <!-- /.row -->
            
            <!-- ./box-body -->
           
            <!-- /.box-footer -->
          
          <!-- /.box -->
      
        <!-- /.col -->
     
      <!-- /.row -->

      <!-- Main row -->
      
            <!-- /.box-body -->
            
            <!-- /.box-footer -->
          
          <!-- /.box -->
        </div>
        <!-- /.col -->
     
      <!-- /.row -->
    
    <!-- /.content -->
 
  <!-- /.content-wrapper -->