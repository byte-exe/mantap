<html>
<head>
	<title>malasngoding.com</title>
</head>
<body>
	<center><h1>Membuat Upload File Dengan CodeIgniter | MalasNgoding.com</h1></center>
	<?php echo $error;?>

	<?php echo form_open_multipart('admin/c_upload/aksi_upload');?>

	<input type="file" name="photo" />

	<br /><br />

	<input type="submit"" />

</form>

</body>
</html>