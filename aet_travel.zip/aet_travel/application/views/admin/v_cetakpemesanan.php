<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cetak laporan</title>
</head>
<body>




<center>

<h4>Laporan Pemesanan Pelanggan</h4>
<h4>AET Travel Internasional Cabang Padang Pariaman</h4>
<h6>Jln. Raya Sicincin Pariaman KM. 7 Buluah Kasok Sungai Sariak Kec. VII Koto.</h6>
<h6>Telp. 0813 9575 7799</h6>




</center>
<?php
				$koneksi = mysqli_connect('localhost','root','','db_umroh') or die (mysqli_error());
				$sql = "SELECT * FROM pemesanan";
				$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));
				?>
	
		
	<br>	
<style>
	table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
	
	<?php


		
			

			$no = 1;

			$sql = "SELECT nama, kelas, nama_paket, tgl_pesan, tanggal FROM `pemesanan`  JOIN
      jadwal 
      ON pemesanan.id_jadwal = jadwal.id_jadwal";
			$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));

			echo "<table class='table table-striped table-bordered' width='100%'>
					<thead align='center'>
						<tr align='center'>
                            <th>No</th>
							<th>Nama Lengkap</th>
							<th>Program</th>
              <th>Nama Paket</th>
							<th>Tanggal Pemesanan</th>
              <th>Tanggal Keberangkatan</th>
						</tr>
					</thead>
					<tbody>";

					while($data1 = mysqli_fetch_array($query)){?>
						
						<tr align="center">
                            <td><?php echo $no;?></td>
							<td><?php echo $data1['nama'];?></td>
							<td><?php echo $data1['kelas'];?></td>
              <td><?php echo $data1['nama_paket'];?></td>
							<td><?php echo $data1['tgl_pesan'];?></td>
              <td><?php echo $data1['tanggal'];?></td>
						</tr>

						<?php $no++; ?>

					<?php }

			echo "	</tbody>
				  </table>";

		
			
	?>

<div align="right">
    <div>
	<p>Pariaman, <span id="tanggalwaktu"></span></p>
	<script>
	var tw = new Date();
	if (tw.getTimezoneOffset() == 0) (a=tw.getTime() + ( 7 *60*60*1000))
	else (a=tw.getTime());
	tw.setTime(a);
	var tahun= tw.getFullYear ();
	var hari= tw.getDay ();
	var bulan= tw.getMonth ();
	var tanggal= tw.getDate ();
	var hariarray=new Array("Minggu,","Senin,","Selasa,","Rabu,","Kamis,","Jum'at,","Sabtu,");
	var bulanarray=new Array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","Nopember","Desember");
	document.getElementById("tanggalwaktu").innerHTML = hariarray[hari]+" "+tanggal+" "+bulanarray[bulan]+" "+tahun;
	
	</script>
	</div>
	<br>
	<br>
	<br>
	
	<p>
		<u>(Pimpinan)</u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</p>
 </div>

</body>
</html>

<table>
 <script>
 window.print()
 </script>
 </table>