<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cetak laporan</title>
</head>
<body>




<center>

<h4>Laporan Data Pelanggan</h4>
<h4>AET Travel Internasional Cabang Padang Pariaman</h4>
<h6>Jln. Raya Sicincin Pariaman KM. 7 Buluah Kasok Sungai Sariak Kec. VII Koto.</h6>
<h6>Telp. 0813 9575 7799</h6>




</center>
<?php
				$koneksi = mysqli_connect('localhost','root','','db_umroh') or die (mysqli_error());
				$sql = "SELECT * FROM pelanggan";
				$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));
				?>
	
		
	<br>	
<style>
	table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
	
	<?php


		
			

			$no = 1;

			$sql = "SELECT * FROM pelanggan";
			$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));

			echo "<table class='table table-striped table-bordered' width='100%'>
					<thead align='center'>
						<tr align='center'>
                            <th>No</th>
							<th>Nama</th>
							<th>NIK</th>
              <th>Nama Ayah</th>
							<th>Golongan Darah</th>
              <th>Tempat, Tanggal Lahir</th>
			  <th>Pernikahan</th>
			  <th>Pendidikan</th>
			  <th>Pekerjaan</th>
			  <th>Jenis Kelamin</th>
			  <th>Alamat</th>
			  <th>No Pasport</th>
			  <th>Tanggal Terbit Passport</th>
						</tr>
					</thead>
					<tbody>";

					while($data1 = mysqli_fetch_array($query)){?>
						
						<tr align="center">
                            <td><?php echo $no;?></td>
							<td><?php echo $data1['nama'];?></td>
							<td><?php echo $data1['nik'];?></td>
              <td><?php echo $data1['ayah'];?></td>
							<td><?php echo $data1['darah'];?></td>
              <td><?php echo $data1['lahir'];?>, <?php echo $data1['tgl_lhr'];?></td>
			  <td><?php echo $data1['pernikahan'];?></td>
			  <td><?php echo $data1['pendidikan'];?></td>
			  <td><?php echo $data1['pekerjaan'];?></td>
			  <td><?php echo $data1['jk'];?></td>
			  <td><?php echo $data1['alamat'];?></td>
			  <td><?php echo $data1['no_passport'];?></td>
			  <td><?php echo $data1['tgl_terbit'];?></td>
						</tr>

						<?php $no++; ?>

					<?php }

			echo "	</tbody>
				  </table>";

		
			
	?>

<div align="right">
    <div>
	<p>Pariaman, <span id="tanggalwaktu"></span></p>
	<script>
	var tw = new Date();
	if (tw.getTimezoneOffset() == 0) (a=tw.getTime() + ( 7 *60*60*1000))
	else (a=tw.getTime());
	tw.setTime(a);
	var tahun= tw.getFullYear ();
	var hari= tw.getDay ();
	var bulan= tw.getMonth ();
	var tanggal= tw.getDate ();
	var hariarray=new Array("Minggu,","Senin,","Selasa,","Rabu,","Kamis,","Jum'at,","Sabtu,");
	var bulanarray=new Array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","Nopember","Desember");
	document.getElementById("tanggalwaktu").innerHTML = hariarray[hari]+" "+tanggal+" "+bulanarray[bulan]+" "+tahun;
	
	</script>
	</div>
	<br>
	<br>
	<br>
	
	<p>
		<u>(Pimpinan)</u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</p>
 </div>

</body>
</html>

<table>
 <script>
 window.print()
 </script>
 </table>