   
    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          
            

            <div class="info-box-content">
           
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
 <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Informasi Data Pelanggan AET Internasional</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                
                <div class="btn-group">
                  
                  
                </div>
               
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <section class="content-header">
      
        
              
    </section>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Lihat Data Pelanggan AET Travel Internasional</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <a href="<?php echo base_url()."admin/pemesanan/cetakpelanggan/"; ?>"><button type="button" class="btn btn-info fa fa-print">Print</button></a>
                <div class="btn-group">
                  
                  
                </div>
               
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <section class="content-header">
      
           <table class="table table-bordered table-striped table-hover overflow-y: auto;">
                <tr>
                  <th >No</th>
                  
                  <th >Nama Pelanggan</th>
                  <th >NIK</th>
                  <th >Nama Ayah</th>
                  <th >Golongan Darah</th>
                  <th >Pekerjaan</th>
                  <th >Pernikahan</th>
                  <th >Pendidikan</th>
                  <th >Jenis Kelamin</th>
                  <th >Tempat, Tanggal Lahir</th>
                  <th>No Tlp</th>
                  <th>Alamat</th>
                  <th>No Passport</th>
                  <th>Tgl Terbit Passport</th>
                  
                  <th >Document</th>
                  <th >Action</th>
                </tr>
                
    <?php 
    $no = 1;
    foreach($pelanggan as $data){ 
    ?>
    <tr>
      <td><?php echo $no++ ?></td>
      <td><?php echo $data->nama ?></td>
      <td><?php echo $data->nik ?></td>
      <td><?php echo $data->ayah ?></td>
      <td><?php echo $data->darah ?></td>
      <td><?php echo $data->pekerjaan ?></td>
      <td><?php echo $data->pernikahan ?></td>
      <td><?php echo $data->pendidikan ?></td>
      <td><?php echo $data->jk ?></td>
      <td>
      <?php echo $data->lahir ?>, <?php echo $data->tgl_lhr ?></td>
      <td><?php echo $data->no_tlp ?></td>
     
      <td><?php echo $data->alamat ?></td>
      <td><?php echo $data->no_passport ?></td>
      <td><?php echo $data->tgl_terbit ?></td>
      <td><img width="100" height="100" src=../assets/images/<?php echo $data->photo ?>></td>
      <td>
        <!-- <a href="<?php echo base_url()."admin/datapelanggan/editdatapelanggan/$data->id"; ?>"><button type="button" class="btn btn-success">Edit</button></a> -->
      <a href="<?php echo base_url()."admin/datapelanggan/hapusdatapelanggan/$data->id"; ?>" onclick="return confirm ('Yakin Mau Di Hapus ?')"><button type="button" class="btn btn-danger" id="demo">Hapus</button></a></td>
    </tr>
    <?php } ?>
  
              
              </table>
    </section>
      
            </div>
                        <div class="box-footer">
              
          
            </div>
       
          </div>
     
        </div>
  
      </div>
      </section>

              </div>
        
 
             
<script>
function myFunction() {
var result = confirm("Want to delete?");
if (result) {
    //Logic to delete the item
}
    document.getElementById("demo").innerHTML = x;
}
</script>          
              
<script type="text/javascript"> /* script JQuery untuk load gambar pada bagian preview */
    $(function() {
      $("#file").change(function() {
        $("#message").empty(); // To remove the previous error message
        var file = this.files[0];
        var imagefile = file.type;
        var match= ["image/jpeg","image/png","image/jpg"];

        if (!((imagefile==match[0]) || (imagefile==match[1]) || (imagefile==match[2])))
        {
          $('#previewing').attr('src','noimage.png');
          $("#message").html("<p id='error'>Please Select A valid Image File</p>"+"<h4>Note</h4>"+"<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
          return false;
        }else {
          var reader = new FileReader();
          reader.onload = imageIsLoaded;
          reader.readAsDataURL(this.files[0]);
        }
      });
    });

    function imageIsLoaded(e) {
      $("#file").css("color","green");
      $('#image_preview').css("display", "block");
      $('#previewing').attr('src', e.target.result);
      $('#previewing').attr('width', '100px');
      $('#previewing').attr('height', '100px');
    }
  </script>