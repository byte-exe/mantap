   <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          
            

            <div class="info-box-content">
           
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        
         
            
            <!-- /.box-header -->
<section class="content-header">
<div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Halaman Admin AET Travel Internasional cabang Padang Pariaman</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <div class="btn-group">
                  
                  
                </div>
               
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <section class="content-header">
      
      <h1 align="center">
       AET Travel Internasional<br>
       Cabang Padang Pariaman
      </h1>
      
     <center><img src="<?php echo base_url() ?>assets/dist/img/LOGO.jpg" width="250" height="250"></center>
      <h4 align="center">
      Jln. Raya Sicincin – Pariaman KM. 7 Buluah Kasok Sungai Sariak Kec. VII Koto.
<br>
Telp. 0813 9575 7799
        
      </h4>
    </section>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
	</section>

              </div>
              <!-- /.row -->
            
            <!-- ./box-body -->
           
            <!-- /.box-footer -->
          
          <!-- /.box -->
      
        <!-- /.col -->
     
      <!-- /.row -->

      <!-- Main row -->
      
            <!-- /.box-body -->
            
            <!-- /.box-footer -->
          
          <!-- /.box -->
        </div>
        <!-- /.col -->
     
      <!-- /.row -->
    
    <!-- /.content -->
 
  <!-- /.content-wrapper -->