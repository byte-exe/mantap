<div class="container">

			<!-- pricing table -->
			<h1 class="heading">Kontak Kami</h1>
			<center>
			<h4>Jln. Raya Sicincin – Pariaman KM. 7 Buluah Kasok Sungai Sariak Kec. VII Koto.</h4> 
<h4>Telp. 0813 9575 7799</h4>
</center>
</div>
<center><table width="1000" height="500">
<tr>
<td><center>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7979.223389938567!2d100.21782892412389!3d-0.5831157482983145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2fd4e22b80d21da7%3A0xedc839e8f7aa651c!2sJl.%20Raya%20Pariaman%20-%20Sicincin%2C%20Sumatera%20Barat!5e0!3m2!1sid!2sid!4v1672512932547!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div></td></tr></table><center>
