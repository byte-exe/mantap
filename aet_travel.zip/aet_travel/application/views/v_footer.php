</tr></table></div></div></div></div>
   <div class="general_social_icons">
  
</div>
<!-- general -->
  
    <div class="info">
  <div class="footer_grids">
        <div class="col-md-3 footer_grid">
          <h3>KONTAK</h3>
          
            <li><a href="<?php echo base_url().'kontak'?>">Alamat</a></li>
            <li><a href="<?php echo base_url().'kontak'?>">Kantor Pusat</a></li>
            <li><a href="<?php echo base_url().'kontak'?>">Email</a></li>
            <li><a href="<?php echo base_url().'home'?>">FAQ's</a></li>
            
          
        </div>
        <div class="col-md-3 footer_grid">
          <h3>LAYANAN</h3>
          
            <li><a href="<?php echo base_url().'jadwal'?>">Umroh</a></li>
            <li><a href="<?php echo base_url().'jadwal'?>">Haji Plus</a></li>
            
            
          
        </div>
        <div class="col-md-3 footer_grid">
          <h3>INFORMASI</h3>
           
            <li><a href="groceries.html">Tentang Kami</a></li>
            <li><a href="household.html">Testimoni</a></li>
            <li><a href="personalcare.html">Galeri</a></li>
            
          
        </div>
        
        <div class="col-md-3 footer_grid">
          <h3>BERITA & ARTIKEL</h3>
          
            <li><a href="<?php echo base_url().'berita'?>">Berita</a></li>
            <li><a href="<?php echo base_url().'jadwal'?>">Jadwal</a></li>
            <li><a href="<?php echo base_url().'registrasi'?>">Login</a></li>
            
          
        </div>
        <div class="clearfix"> </div>
      </div>
  </div>
  <div class="footer">
    <h5 align="center"><a href="index.html">Copyright <?php echo date("Y");?> AET Travel Internasional Cabang Padang Pariaman</a></h5>
  </div>